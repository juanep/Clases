
/** \brief valida edad laboral
 *
 * \param edad a validar
 * \return 1 si la edad esta dentro del rango 18-65 o 0 si no lo esta
 *
 */


int validarRango(int valor, int lmin, int lsup){


return !( valor < lmin || valor > lsup);


}
