
int validarRango(int valor, int lmin, int lsup);
